package com.example.Employee.Performance.Exceptions;

public class APIException extends Throwable {
    private static final long serialVersionUID = 1L;

    public APIException() {
    }
    public APIException(String message){
        super(message);
    }
}
