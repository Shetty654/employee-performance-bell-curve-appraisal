package com.example.Employee.Performance.Controllers;

import com.example.Employee.Performance.Services.BellCurveService;
import com.example.Employee.Performance.payload.APIResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/public")
public class BellCurveController {

    @Autowired
    private BellCurveService bellCurveService;

    @PostMapping(value = "/calculate-bell-curve", produces = "application/json")
    public ResponseEntity<APIResponse> calculateBellCurve() {
        APIResponse response = bellCurveService.calculateBellCurve();
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}
