package com.example.Employee.Performance.Models;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "appraisal")
public class Appraisal {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private double outstandingPercentage;
    private double veryGoodPercentage;
    private double goodPercentage;
    private double needsImprovementPercentage;
    private double lowPerformerPercentage;

    public double getOutstandingPercentage() {
        return outstandingPercentage;
    }

    public double getVeryGoodPercentage() {
        return veryGoodPercentage;
    }

    public double getGoodPercentage() {
        return goodPercentage;
    }

    public double getNeedsImprovementPercentage() {
        return needsImprovementPercentage;
    }

    public double getLowPerformerPercentage() {
        return lowPerformerPercentage;
    }
}
