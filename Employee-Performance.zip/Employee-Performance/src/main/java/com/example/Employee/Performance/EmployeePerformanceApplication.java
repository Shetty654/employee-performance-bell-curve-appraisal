package com.example.Employee.Performance;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeePerformanceApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeePerformanceApplication.class, args);
	}

}
