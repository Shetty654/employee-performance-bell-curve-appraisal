package com.example.Employee.Performance.Repositories;

import com.example.Employee.Performance.Models.Appraisal;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AppraisalRepository extends JpaRepository<Appraisal, Long> {

    // Fetch the latest appraisal based on the highest ID (most recent record)
    Appraisal findTopByOrderByIdDesc();
}
