package com.example.Employee.Performance.Services;

import com.example.Employee.Performance.Exceptions.APIException;
import com.example.Employee.Performance.Models.Employee;
import com.example.Employee.Performance.payload.EmployeeDTO;
import com.example.Employee.Performance.payload.EmployeeResponse;
import org.springframework.stereotype.Service;

public interface EmployeeService {
    public EmployeeResponse getAllEmployees(Integer pageNo, Integer pageSize, String sortBy, String sortOrder) throws APIException;
    public EmployeeDTO addEmployee(EmployeeDTO employeeDTO);
}
