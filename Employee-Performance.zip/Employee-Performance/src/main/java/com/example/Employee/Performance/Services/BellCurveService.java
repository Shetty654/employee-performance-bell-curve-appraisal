package com.example.Employee.Performance.Services;

import com.example.Employee.Performance.Models.Appraisal;
import com.example.Employee.Performance.Models.Employee;
import com.example.Employee.Performance.Models.Ratings;
import com.example.Employee.Performance.Repositories.AppraisalRepository;
import com.example.Employee.Performance.Repositories.EmployeeRespsitory;
import com.example.Employee.Performance.payload.APIResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class BellCurveService {

    @Autowired
    private EmployeeRespsitory employeeRespsitory;

    @Autowired
    private AppraisalRepository appraisalRepository;

    public APIResponse calculateBellCurve() {
        // Fetch employees
        List<Employee> employees = employeeRespsitory.findAll();

        // If no employees are found, return early
        if (employees.isEmpty()) {
            return new APIResponse("No employees found for the bell curve calculation.", false, null);
        }

        // Calculate actual percentages based on ratings
        int totalEmployees = employees.size();
        Map<Ratings, Long> ratingCounts = employees.stream()
                .collect(Collectors.groupingBy(Employee::getRating, Collectors.counting()));

        Map<Ratings, Double> actualPercentages = new HashMap<>();
        for (Ratings category : Ratings.values()) {
            actualPercentages.put(category, (ratingCounts.getOrDefault(category, 0L) * 100.0) / totalEmployees);
        }

        // Fetch the latest appraisal record for standard percentages
        Appraisal appraisal = appraisalRepository.findTopByOrderByIdDesc();
        if (appraisal == null) {
            return new APIResponse("No appraisal data found.", false, null);
        }

        Map<Ratings, Double> standardPercentages = new HashMap<>();
        standardPercentages.put(Ratings.OUTSTANDING, appraisal.getOutstandingPercentage());
        standardPercentages.put(Ratings.VERY_GOOD, appraisal.getVeryGoodPercentage());
        standardPercentages.put(Ratings.GOOD, appraisal.getGoodPercentage());
        standardPercentages.put(Ratings.NEEDS_IMPROVEMENT, appraisal.getNeedsImprovementPercentage());
        standardPercentages.put(Ratings.LOW_PERFORMER, appraisal.getLowPerformerPercentage());

        // List to store employees whose ratings need revision
        List<Employee> employeesToRevise = new ArrayList<>();

        // Calculate deviation and suggest revisions
        for (Ratings category : Ratings.values()) {
            double actualPercentage = actualPercentages.get(category);
            double standardPercentage = standardPercentages.get(category);
            double deviation = actualPercentage - standardPercentage;

            // Adjust the threshold as needed, e.g., 5% deviation
            if (Math.abs(deviation) > 5.0) {
                // Add employees to revision list if deviation exceeds threshold
                List<Employee> employeesInCategory = employees.stream()
                        .filter(e -> e.getRating().equals(category))
                        .collect(Collectors.toList());
                employeesToRevise.addAll(employeesInCategory);
            }
        }

        // Return response based on findings
        if (employeesToRevise.isEmpty()) {
            return new APIResponse("No employees need revisions based on the bell curve calculation.", true, null);
        } else {
            return new APIResponse("Bell curve calculation completed. Employees to revise: ", true, employeesToRevise);
        }
    }
}
