package com.example.Employee.Performance.Services;

import com.example.Employee.Performance.Exceptions.APIException;
import com.example.Employee.Performance.Models.Employee;
import com.example.Employee.Performance.Repositories.EmployeeRespsitory;
import com.example.Employee.Performance.payload.EmployeeDTO;
import com.example.Employee.Performance.payload.EmployeeResponse;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeServiceImpl implements EmployeeService {
    @Autowired
    ModelMapper modelMapper;
    @Autowired
    EmployeeRespsitory employeeRespsitory;
    @Override
    public EmployeeDTO addEmployee(EmployeeDTO employeeDTO) {
        Employee employee = modelMapper.map(employeeDTO, Employee.class);
        EmployeeDTO savedEmployee = modelMapper.map(employeeRespsitory.save(employee), EmployeeDTO.class);
        return savedEmployee;
    }

    public EmployeeResponse getAllEmployees(Integer pageNumber, Integer pageSize, String sortBy, String sortOrder) throws APIException {
        Sort sortByAndOrder = sortOrder.equalsIgnoreCase("asc")
                ? Sort.by(sortBy).ascending()
                : Sort.by(sortBy).descending();
        Pageable pageDetails = PageRequest.of(pageNumber, pageSize, sortByAndOrder);
        Page<Employee> page = employeeRespsitory.findAll(pageDetails);
        List<Employee> employees = page.getContent();
        if(employees.isEmpty())
            throw new APIException("No employee created till now");
        List<EmployeeDTO> employeeDTOS = employees.stream()
                .map(employee -> modelMapper.map(employee, EmployeeDTO.class)).toList();
        EmployeeResponse employeeResponse = new EmployeeResponse();
        employeeResponse.setContent(employeeDTOS);
        employeeResponse.setPageNumber(page.getNumber());
        employeeResponse.setPageSize(page.getSize());
        employeeResponse.setTotalElements(page.getTotalElements());
        employeeResponse.setTotalPages(page.getTotalPages());
        employeeResponse.setLastPage(page.isLast());
        return employeeResponse;
    }
}
