package com.example.Employee.Performance.Models;

public enum Ratings {
    OUTSTANDING("A"),
    VERY_GOOD("B"),
    GOOD("C"),
    NEEDS_IMPROVEMENT("D"),
    LOW_PERFORMER("E");

    private final String code;

    Ratings(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }
}