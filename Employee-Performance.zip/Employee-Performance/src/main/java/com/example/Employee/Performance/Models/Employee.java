package com.example.Employee.Performance.Models;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "employee")
public class Employee {
    @Id
    private Long employeeId;

    @NotNull(message = "Employee name is required")
    private String employeeName;

    @Enumerated(EnumType.STRING)
    private Ratings rating;

    public Long getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(Long employeeId) {
        this.employeeId = employeeId;
    }

    public @NotNull(message = "Employee name is required") String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(@NotNull(message = "Employee name is required") String employeeName) {
        this.employeeName = employeeName;
    }

    public Ratings getRating() {
        return rating;
    }

    public void setRating(Ratings rating) {
        this.rating = rating;
    }
}
