package com.example.Employee.Performance.payload;

import com.example.Employee.Performance.Models.Ratings;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


public class EmployeeDTO {
    @NotNull
    private Long employeeId;
    @NotNull
    private String employeeName;
    @NotNull
    private Ratings rating;

    public EmployeeDTO() {
    }

    public EmployeeDTO(Long employeeId, String employeeName, Ratings rating) {
        this.employeeId = employeeId;
        this.employeeName = employeeName;
        this.rating = rating;
    }

    public @NotNull Long getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(@NotNull Long employeeId) {
        this.employeeId = employeeId;
    }

    public @NotNull String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(@NotNull String employeeName) {
        this.employeeName = employeeName;
    }

    public @NotNull Ratings getRating() {
        return rating;
    }

    public void setRating(@NotNull Ratings rating) {
        this.rating = rating;
    }
}
