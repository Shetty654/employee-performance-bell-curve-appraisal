package com.example.Employee.Performance.Controllers;

import com.example.Employee.Performance.Configuration.AppConstants;
import com.example.Employee.Performance.Exceptions.APIException;
import com.example.Employee.Performance.Models.Employee;
import com.example.Employee.Performance.Services.EmployeeService;
import com.example.Employee.Performance.payload.EmployeeDTO;
import com.example.Employee.Performance.payload.EmployeeResponse;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class EmployeeController {
    @Autowired
    private EmployeeService employeeService;
    @PostMapping("/api/public/employees")
    public ResponseEntity<EmployeeDTO> addEmployee(@Valid @RequestBody EmployeeDTO employee) {
        EmployeeDTO savedEmployee=employeeService.addEmployee(employee);
        return new ResponseEntity<>(savedEmployee, HttpStatus.CREATED);
    }

    @GetMapping("/api/public/employees")
    public ResponseEntity<EmployeeResponse> getAllEmployee(
            @RequestParam(name = "pageNumber", defaultValue = AppConstants.PAGE_NUMBER, required = false) Integer pageNumber,
            @RequestParam(name = "pageSize", defaultValue = AppConstants.PAGE_SIZE, required = false) Integer pageSize,
            @RequestParam(name = "sortBy", defaultValue = AppConstants.SORT_EMPLOYEES_BY, required = false) String sortBy,
            @RequestParam(name = "sortOrder", defaultValue = AppConstants.SORT_DIR, required = false) String sortOrder
    ) throws APIException {
        EmployeeResponse employeeResponse = employeeService.getAllEmployees(pageNumber, pageSize, sortBy, sortOrder);
        return new ResponseEntity<>(employeeResponse, HttpStatus.OK);
    }
}
